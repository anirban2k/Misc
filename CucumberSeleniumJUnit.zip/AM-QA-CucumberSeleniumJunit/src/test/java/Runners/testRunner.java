package Runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

	@RunWith(Cucumber.class)
	@CucumberOptions(
			//features="C:\\.....\\CucumberSelBaseFrmWrk\\src\\test\\java\\Features\\initialScope.feature", 			// using absolute path of the feature file
			features="src/test/java/Features/initialScope.feature", 													// using relative path of the feature file
			//features="src/test/java/Features/initialScope.feature", 													// using relative path of multiple feature files
			glue={"stepDefinitions"}, 																					// package path of the step definition files
			format= {"pretty","html:test-output", "junit:junit_xml/cucumber.xml", "json:json_output/cucumber.json"}, 	// generate different types of reporting
			monochrome = true, 																							// display the console output in a format which do not contain codes
			strict = true, 																								// check and report error in console, if any step is not defined in step definition file
			dryRun = false,																								// check the mapping is proper between feature file and step definition file
			//tags = {"@SmokeTest"}																						// Run only scenarios which have @SmokeTest
			tags = {"@EndToEnd"}																						// Run only scenarios which have @EndToEnd
			//tags = {"@SmokeTest", "@EndToEnd"}																		// Run only scenarios which have @SmokeTest AND @EndToEnd
			//tags = {"@SmokeTest, @EndToEnd"}																			// Run only scenarios which have @SmokeTest OR @EndToEnd
		)

public class testRunner {

}
	
/*
-------------------------------------------------------------------------------------------------------------------
To Run this Suite:
1. Update the Feature File Path in Line Number 10 above
2. Run this Test as JUnit
-------------------------------------------------------------------------------------------------------------------
*/