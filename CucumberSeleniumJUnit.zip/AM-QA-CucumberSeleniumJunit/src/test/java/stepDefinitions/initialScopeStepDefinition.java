package stepDefinitions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class initialScopeStepDefinition {

	WebDriver driver;
	
	@SuppressWarnings("deprecation")
	@Before()
	public void initiateApp() {
		URL resource = initialScopeStepDefinition.class.getResource("initialScopeStepDefinition.class");
		System.out.println("Path of Properties File : " + resource.toString().replace("%20", " ").toString().replace("file:/", "").toString().replace("target/test-classes/stepDefinitions/initialScopeStepDefinition.class", "").toString().replace("/", "\\")+"src\\test\\resources\\properties\\application.properties");
		File overallProperties = new File(resource.toString().replace("%20", " ").toString().replace("file:/", "").toString().replace("target/test-classes/stepDefinitions/initialScopeStepDefinition.class", "").toString().replace("/", "\\")+"src\\test\\resources\\properties\\application.properties");
		//File overallProperties = new File("C:\\......\\CucumberSelBaseFrmWrk\\src\\test\\resources\\properties\\application.properties");
		FileInputStream overallInput = null;
		try {
			overallInput = new FileInputStream(overallProperties);
		} catch (FileNotFoundException e) {
			System.out.println("Not able to locate the properties File");
		}
		Properties prop = new Properties();
		try {
			prop.load(overallInput);
		} catch (IOException e) {
			System.out.println("Encountered IOException while loading the properties File");
		}
		/*
		if(prop.getProperty("BROWSER").equalsIgnoreCase("Chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else if(prop.getProperty("BROWSER").equalsIgnoreCase("FireFox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else if(prop.getProperty("BROWSER").equalsIgnoreCase("IE")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else if(prop.getProperty("BROWSER").equalsIgnoreCase("EDGE")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		driver.get(prop.getProperty("URL"));
		driver.manage().window().maximize();*/
		System.out.println("Launching the Application (" + prop.getProperty("URL") + ") using " + prop.getProperty("BROWSER"));
		Assert.assertEquals("Launching the Application (" + prop.getProperty("URL") + ") using " + prop.getProperty("BROWSER"), "Launching the Application (" + prop.getProperty("URL") + ") using " + prop.getProperty("BROWSER"));
	}
	
	@Given("^This is a valid HomePage$")
	public void this_is_a_valid_HomePage() {
		System.out.println("Validating the title of the Homepage");
		System.out.println("Validating the Headings of the Homepage");
		System.out.println("Validating the Labels of the Homepage");
		System.out.println("Validating the Fields of the Homepage");
		System.out.println("Validating the Field Values of the Homepage");
	}
	
	@When("^User clicks on Menu(\\d+)$")
	public void user_clicks_on_Menu(int arg1) {
		System.out.println("Clicking on Menu " + arg1);
	}
	
	@Then("^User is on Menu(\\d+) Page$")
	public void user_is_on_Menu_Page(int arg1) {
		System.out.println("Validating the title of the Menu" + arg1 + " Page");
		System.out.println("Validating the Headings of the Menu" + arg1 + " Page");
		System.out.println("Validating the Labels of the Menu" + arg1 + " Page");
		System.out.println("Validating the Fields of the Menu" + arg1 + " Page");
		System.out.println("Validating the Field Values of the Menu" + arg1 + " Page");
	}
	
	@Then("^User navigates back to HomePage$")
	public void user_navigates_back_to_HomePage() {
		System.out.println("Navigating back to the HomePage");
	}
	
	@Then("^User is on HomePage$")
	public void user_is_on_HomePage() {
		System.out.println("Validating the title of the Homepage");
		System.out.println("Validating the Headings of the Homepage");
		System.out.println("Validating the Labels of the Homepage");
		System.out.println("Validating the Fields of the Homepage");
		System.out.println("Validating the Field Values of the Homepage");
	}
	
	@When("^User navigates to Module(\\d+)$")
	public void user_navigates_to_Module(int arg1) {
		System.out.println("Navigating to Module " + arg1);
	}
	
	@Then("^User is on Module(\\d+) Page$")
	public void user_is_on_Module_Page(int arg1) {
		System.out.println("Validating the title of the Module" + arg1 + " Page");
		System.out.println("Validating the Headings of the Module" + arg1 + " Page");
		System.out.println("Validating the Labels of the Module" + arg1 + " Page");
		System.out.println("Validating the Fields of the Module" + arg1 + " Page");
		System.out.println("Validating the Field Values of the Module" + arg1 + " Page");
	}
	
	@Then("^User fills up Module(\\d+) Form$")
	public void user_fills_up_Module_Form(int arg1) {
		System.out.println("Filling in the form of Module" + arg1 + " Page");
		System.out.println("Click on Save / Submit");
	}
	
	@Then("^User confirms form submission$")
	public void user_confirms_form_submission() {
		System.out.println("Validating the Form entry from some acknowledgement");
	}
	
	@Then("^User fills up Module(\\d+) Form with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_fills_up_Module_Form_with_and(int arg1, String arg2, String arg3) {
		System.out.println("Filling in the form of Module" + arg1 + " Page with : " + arg2);
		System.out.println("Filling in the form of Module" + arg1 + " Page with : " + arg3);
	}

	@Then("^User fills up Module(\\d+) Form with data(\\d+) and data(\\d+)$")
	public void user_fills_up_Module_Form_with_data_and_data(int arg1, int arg2, int arg3, DataTable arg4) {
		List<List<String>> data = arg4.raw();
		System.out.println("Filling in the form of Module" + arg1 + " Page with : " + arg2 + " and " + arg3 + " and " + data.get(0).get(0) + " and " + data.get(0).get(1));
	}
	
	@Then("^User fills up Module(\\d+) Form with various data$")
	public void user_fills_up_Module_Form_with_various_data(int arg1, DataTable arg2) {
		for (Map<String, String> data : arg2.asMaps(String.class, String.class)) {
			System.out.println("Filling in the form of Module" + arg1 + " Page with : " + data.get("data1") + " and " + data.get("data2") + " and " + data.get("data3"));
		}
	}
	
	@After(order=1)
	public void tearDownApp1() {
		System.out.println("Clicking Signout");
		System.out.println("Validating if the application is properly signed out");
	}
	
	@After(order=2)
	public void tearDownApp2() {
		System.out.println("Closing the Application");
		//driver.close();
		System.out.println("Quitting the Application");
		//driver.quit();
	}
}
